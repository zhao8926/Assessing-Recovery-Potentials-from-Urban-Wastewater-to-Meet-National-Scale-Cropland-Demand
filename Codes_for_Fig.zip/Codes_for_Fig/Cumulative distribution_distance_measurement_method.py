import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Read data from Excel file
file_path = "Three distance measurement methods.xlsx"
df = pd.read_excel(file_path)

# Extract three columns and drop missing values
data1 = df["PVTD_road (km/Mg P)"].dropna()       # Road network distance
data2 = df["PVTD_grid (km/Mg P)"].dropna()       # Grid-based distance
data3 = df["PVTD_Euclidean (km/Mg P)"].dropna()  # Euclidean distance

# Calculate cumulative distribution function (CDF)
def calculate_cdf(data):
    sorted_data = np.sort(data)
    cdf = np.arange(1, len(data) + 1) / len(data)
    return sorted_data, cdf

# Plot CDF curves
def plot_cdf(data1, data2, data3):
    x1, y1 = calculate_cdf(data1)
    x2, y2 = calculate_cdf(data2)
    x3, y3 = calculate_cdf(data3)

    plt.figure(figsize=(90 / 25.4, 60 / 25.4))  # Set figure size: width 90mm, height 60mm

    plt.plot(x1, y1, label='Road network distance', color='#fd8f52', linewidth=2)   # Orange
    plt.plot(x2, y2, label='Grid-based distance', color='#2d82b5', linewidth=2)       # Blue
    plt.plot(x3, y3, label='Euclidean distance', color='#339c9d', linewidth=2)       # Cyan

    # Set axis labels with Times New Roman font
    plt.xlabel('P vehicle transport distance (km/Mg P)', fontname='Times New Roman', fontsize=8)
    plt.ylabel('Cumulative probability', fontname='Times New Roman', fontsize=8)

    # Set tick label fonts and direction (ticks facing inward)
    plt.xticks(fontname='Times New Roman', fontsize=6)
    plt.yticks(fontname='Times New Roman', fontsize=6)
    plt.tick_params(axis='both', direction='in', which='both')

    # Set legend with font properties, positioned at lower right corner
    plt.legend(prop={'family': 'Times New Roman', 'size': 6}, bbox_to_anchor=(0.2, 0.85), frameon=False)

    # Disable grid lines
    plt.grid(False)

    # Save figure as SVG with tight bounding box
    output_path = "Three_distance_measurement_methods_Fig_4d.svg"
    plt.savefig(output_path, format='svg', bbox_inches='tight')

    # Show plot
    plt.show()

# Call the plotting function
plot_cdf(data1, data2, data3)
