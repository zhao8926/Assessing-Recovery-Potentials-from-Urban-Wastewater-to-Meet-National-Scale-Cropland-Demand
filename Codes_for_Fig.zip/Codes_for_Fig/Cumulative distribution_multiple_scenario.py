import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Read data from Excel file
file_path = "Multiple scenario comparison summary.xlsx"
df = pd.read_excel(file_path)

# Extract three columns, drop missing values
data1 = df["PVTD_100_0.1265"].dropna()
data2 = df["PVTD_100_5Mg"].dropna()
data3 = df["PVTD_100_35Mg"].dropna()

# Calculate Cumulative Distribution Function (CDF)
def calculate_cdf(data):
    sorted_data = np.sort(data)
    cdf = np.arange(1, len(data) + 1) / len(data)
    return sorted_data, cdf

# Plot CDF curves
def plot_cdf(data1, data2, data3):
    x1, y1 = calculate_cdf(data1)
    x2, y2 = calculate_cdf(data2)
    x3, y3 = calculate_cdf(data3)

    plt.figure(figsize=(10, 6))

    # Plot three CDF lines with labels and colors
    # plt.plot(x3, y3, label='Calcium phosphate', color='#A0E079', linewidth=2)  # 绿色
    # plt.plot(x1, y1, label='struvite (baseline scenario)', color='#80D5FB', linewidth=2)  # 蓝色
    # plt.plot(x2, y2, label='Treated sludge', color='#F2B8CC', linewidth=2)  # 粉色
    plt.plot(x3, y3, label='35 Mg', color='#f7e17d', linewidth=2)  # Yellow line
    plt.plot(x1, y1, label='Optimal vehicle combination (baseline scenario)', color='#274e5a', linewidth=2)  # Dark line
    plt.plot(x2, y2, label='5 Mg', color='#d56c50', linewidth=2)  # Red line
    # plt.plot(x1, y1, label='100% (baseline scenario)', color='#58cae8', linewidth=2)  # 蓝色
    # plt.plot(x2, y2, label='50%', color='#ee929a', linewidth=2)  # 粉色
    # plt.plot(x3, y3, label='25%', color='#f9d02c', linewidth=2)  # 黄色
    # plt.plot(x1, y1, label='Road distance', color='#fd8f52', linewidth=2)  # 橙色
    # plt.plot(x2, y2, label='Grid distance', color='#2d82b5', linewidth=2)  # 蓝色
    # plt.plot(x3, y3, label='Euclidean distance', color='#339c9d', linewidth=2)  # 青色

    # Set axis labels and font size
    plt.xlabel('P vehicle transport distance (km/Mg P)', fontname='Sans Serif Collection', fontsize=10)
    plt.ylabel('Cumulative probability', fontname='Sans Serif Collection', fontsize=10)

    # Set ticks font and direction inside the plot
    plt.xticks(fontname='Sans Serif Collection', fontsize=10)
    plt.yticks(fontname='Sans Serif Collection', fontsize=10)
    plt.tick_params(axis='both', direction='in', which='both')

    # Add legend with custom font and position
    legend = plt.legend(
        prop={'family': 'Sans Serif Collection', 'size': 10},
        loc='lower right',
        frameon=False,
        title='Vehicle load capacity',
        title_fontproperties={'family': 'Sans Serif Collection', 'size': 12},
        alignment='left')

    # Remove grid lines
    plt.grid(False)

    # Save figure with high resolution
    output_path = r"Multiple_scenario_comparison_summary_Vehicle_load.png"
    plt.savefig(output_path, dpi=1200, bbox_inches='tight')

    # Show plot
    plt.show()

# Call the plot function
plot_cdf(data1, data2, data3)
