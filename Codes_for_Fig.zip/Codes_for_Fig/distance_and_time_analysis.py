import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import statsmodels.api as sm
from matplotlib.gridspec import GridSpec
from matplotlib.gridspec import GridSpecFromSubplotSpec

# Set global font to Times New Roman
plt.rcParams['font.family'] = 'Sans Serif Collection'  # 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False

# Read all sheets
file_path = 'Transport_distance_and_time_analysis.xlsx'
xls = pd.ExcelFile(file_path)
sheet_names = xls.sheet_names[:1]  # Read up to the first sheet

# Create outer 2×3 grid for overall figure
fig = plt.figure(figsize=(18, 12))  # Adjust size as needed
outer_gs = GridSpec(1, 1, wspace=0.3, hspace=0.3)

for idx, sheet in enumerate(sheet_names):
    df = pd.read_excel(file_path, sheet_name=sheet)
    x = df.iloc[:, 0]
    y = df.iloc[:, 1]
    x_label = df.columns[0]
    y_label = df.columns[1]
    n = len(df)

    # Regression
    X = sm.add_constant(x)
    model = sm.OLS(y, X).fit()
    r_squared = model.rsquared
    p_value = model.f_pvalue

    x_pred = np.linspace(x.min(), x.max(), 100)
    X_pred = sm.add_constant(x_pred)
    y_pred = model.predict(X_pred)
    pred_summary = model.get_prediction(X_pred).summary_frame(alpha=0.10)
    lower = pred_summary['obs_ci_lower']
    upper = pred_summary['obs_ci_upper']

    # Nested gridspec: each plot divided into 4×4
    inner_gs = GridSpecFromSubplotSpec(4, 4, subplot_spec=outer_gs[idx])

    # Main plot + top density + right density
    main_ax = fig.add_subplot(inner_gs[1:4, 0:3])
    x_dens = fig.add_subplot(inner_gs[0, 0:3], sharex=main_ax)
    y_dens = fig.add_subplot(inner_gs[1:4, 3], sharey=main_ax)

    # Main plot
    main_ax.scatter(x, y, alpha=0.6, label='Data', color='#93be70')
    label_regression = (f'Regression line (n={n})\n'
                    f'$R^2$={r_squared:.2f}, p={p_value:.3f}')
    main_ax.plot(x_pred, y_pred, color='#e35978', label=label_regression)
    main_ax.fill_between(x_pred, lower, upper, color='#faaec5', alpha=0.2, label='90% confidence interval')
    main_ax.set_xlabel(x_label, fontsize=18)
    main_ax.set_ylabel(y_label, fontsize=18)
    main_ax.tick_params(labelsize=10)
    main_ax.legend(loc='upper left', frameon=False, fontsize=15)
    main_ax.grid(False)

    # Top KDE (x distribution)
    sns.kdeplot(x, ax=x_dens, fill=True, color="#a0bc9f")
    x_dens.axis("off")

    # Right KDE (y distribution)
    sns.kdeplot(y, ax=y_dens, fill=True, color="#fad9b9", vertical=True)
    y_dens.axis("off")

# Final layout
plt.tight_layout()
plt.savefig("regression_plots_single2.png", dpi=1200, bbox_inches='tight')  # Save as high-resolution PNG
plt.show()
