import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator

# Set global font to "Times New Roman"
plt.rcParams['font.family'] = 'Sans Serif Collection'

# Read Excel file
file_path = r"Volume_of_treated_water_and_P_recovery_amount.xlsx"
df = pd.read_excel(file_path)

# Check column names and extract data
print(df.columns)  # Verify if columns match below

regions = df["Province"].tolist()
volume_treated_water = df["Volume of treated water (10^4 m3)"].tolist()
p_recovery_amount = df["P recovery amount (Mg P)"].tolist()

# Ensure data length consistency
assert len(regions) == len(volume_treated_water) == len(p_recovery_amount), "Data length mismatch!"

# Create lollipop chart
fig, ax1 = plt.subplots(figsize=(12, 10))

# Create second X-axis
ax2 = ax1.twiny()

# Y-axis indices starting from 0
y = list(range(0, len(regions) * 2, 2))  # Increase step for spacing

# Set offsets for upper and lower data points
y_p = [i + 0.4 for i in y]  # P recovery amount (shifted up)
y_v = [i - 0.4 for i in y]  # Volume of treated water (shifted down)

# Draw lollipop lines (solid line changed to 20% transparent black)
for i in range(len(y)):
    ax1.plot([0, p_recovery_amount[i]], [y_p[i], y_p[i]], color='#59666f', alpha=0.85, linewidth=1)
    ax2.plot([0, volume_treated_water[i]], [y_v[i], y_v[i]], color='#59666f', alpha=0.85, linewidth=1)

# Plot lollipop markers
ax1.scatter(p_recovery_amount, y_p, color='#539fcf', label='P Recovery amount', edgecolor='#539fcf', s=100, zorder=2)
ax2.scatter(volume_treated_water, y_v, color='#75d9b5', label='Annual volume of treated water', edgecolor='#75d9b5', s=100, zorder=2)

# Set fixed X-axis ranges
ax1.set_xlim(0, 25000)         # P Recovery amount
ax2.set_xlim(0, 1000000)       # Volume of treated water

# Custom X-axis tick format (without thousands separator)
formatter = FuncFormatter(lambda x, _: f'{int(x)}')
ax1.xaxis.set_major_formatter(formatter)
ax2.xaxis.set_major_formatter(formatter)

# Set major and minor ticks for X axes (one minor tick between major ticks)
ax1.xaxis.set_major_locator(MultipleLocator(5000))    # Major ticks every 5000
ax1.xaxis.set_minor_locator(MultipleLocator(2500))    # Minor ticks every 2500
ax2.xaxis.set_major_locator(MultipleLocator(200000))  # Major ticks every 200,000
ax2.xaxis.set_minor_locator(MultipleLocator(100000))  # Minor ticks every 100,000

# Set tick direction inward
ax1.tick_params(axis='x', direction='in', which='both', labelsize=16)
ax2.tick_params(axis='x', direction='in', which='both', labelsize=16)

# Set Y-axis labels (hide ticks) and font size
ax1.set_yticks(y)
ax1.set_yticklabels(regions)
ax1.tick_params(axis='y', length=0, labelsize=18)  # Set Y-axis tick label font size

# Invert Y-axis
ax1.invert_yaxis()

# Set X-axis labels with black color, larger font size, and bold weight
ax1.set_xlabel(r'P Recovery amount (Mg P/yr)', color='black', fontsize=24, fontweight='bold', labelpad=20)
ax2.set_xlabel(r'Annual volume of treated water (10$^{4}$ m$^{3}$)', color='black', fontsize=24, fontweight='bold', labelpad=20)

# Adjust legend position (left aligned) and font size 18
ax2.legend(loc='upper left', bbox_to_anchor=(0.47, 1), frameon=False, ncol=1, fontsize=18)
ax1.legend(loc='upper left', bbox_to_anchor=(0.47, 0.97), frameon=False, ncol=1, fontsize=18)

# Set length of major and minor ticks on X axes
ax1.tick_params(axis='x', direction='in', which='both', labelsize=16, length=5)
ax2.tick_params(axis='x', direction='in', which='both', labelsize=16, length=5)

# Set all spines and ticks line width to 1.5
ax1.spines['top'].set_linewidth(1.5)
ax1.spines['bottom'].set_linewidth(1.5)
ax1.spines['left'].set_linewidth(1.5)
ax1.spines['right'].set_linewidth(1.5)

# Set tick width to 1
ax1.tick_params(axis='x', width=1)
ax1.tick_params(axis='y', width=1)
ax2.tick_params(axis='x', width=1)

# plt.show()

# Export figure as 1200 dpi PNG with transparent background
plt.savefig("ED_Fig_1b2.png", dpi=1200, bbox_inches='tight', transparent=True)
